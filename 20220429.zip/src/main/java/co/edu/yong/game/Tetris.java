package co.edu.yong.game;

public class Tetris {

	
public void run() {
		
		System.out.println("테트리스 게임");
		
		
	}
	
	
	
	
	
}
