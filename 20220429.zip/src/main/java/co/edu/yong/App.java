package co.edu.yong;

import co.edu.yong.menu.Menu;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	
    	Menu menu = new Menu();
    	
    	menu.run();
    	
    	
    	
    	
    	
    }
}
